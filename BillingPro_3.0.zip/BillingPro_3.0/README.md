# BillingPro 3.0

Full-stack foundation for a commercial drilling/borewell and dredging management system.

### Included
- Node.js + Express backend
- PostgreSQL database
- JWT authentication in HTTP-only cookies
- bcrypt password hashing
- Helmet security headers
- Multi-company data model
- Users and roles foundation
- Customers
- Drilling and dredging projects
- Daily progress/depth quantity logging
- Equipment/fleet
- Materials/stock
- Expenses
- Invoices
- Dashboard
- Profitability reports
- JSON backup
- Docker Compose
- SQL migration
- Seed/demo data

### Run in VS Code
1. Install Node.js 22+ and PostgreSQL, or Docker Desktop.
2. Open this folder in VS Code.
3. Copy `.env.example` to `.env`.
4. Put a long random value into `JWT_SECRET`.
5. Create the `billingpro` PostgreSQL database.
6. Run `psql "$DATABASE_URL" -f database/migrations/001_init.sql`
7. Run `npm install`
8. Run `npm run seed`
9. Run `npm start`
10. Visit `http://localhost:3000`

Demo login: `admin` / `admin123`

### Docker
Run:
`docker compose up --build`

For a fresh Docker database, run the migration and seed against the database container before using the app.

### Production requirements before selling
This is a strong development foundation, not a completed compliance-certified SaaS. Before real customer use, add:
- enforced password change and account recovery
- robust role/permission checks
- rate limiting and login lockout
- input validation on every route
- CSRF strategy
- production secret management
- automated tests and migrations
- encrypted, tested backups
- monitoring and error tracking
- professional PDF invoice generation
- GST/e-invoicing/e-way-bill integrations after checking current official requirements
- payment/subscription infrastructure
- privacy policy, terms, retention/deletion controls
- independent security review
- production database hosting and disaster recovery
