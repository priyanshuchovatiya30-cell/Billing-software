require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = require("./db");
const auth = require("./middleware/auth");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "../../frontend")));

const q = async (text, params = []) => (await db.query(text, params)).rows;

app.post("/api/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body || {};
    const rows = await q(
      `SELECT u.*, c.name AS company_name
       FROM users u JOIN companies c ON c.id=u.company_id
       WHERE u.username=$1 AND u.active=true`,
      [username]
    );
    const u = rows[0];

    if (!u || !(await bcrypt.compare(password || "", u.password_hash))) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const token = jwt.sign(
      { id: u.id, companyId: u.company_id, role: u.role, name: u.name },
      process.env.JWT_SECRET,
      { expiresIn: "8h" }
    );

    res.cookie("bp_token", token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.COOKIE_SECURE === "true",
      maxAge: 8 * 60 * 60 * 1000
    });

    res.json({
      user: { name: u.name, role: u.role },
      company: { id: u.company_id, name: u.company_name }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Login failed" });
  }
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("bp_token");
  res.json({ ok: true });
});

app.get("/api/auth/me", auth, async (req, res) => {
  const company = (await q("SELECT * FROM companies WHERE id=$1", [req.user.companyId]))[0];
  res.json({ user: req.user, company });
});

const resources = {
  customers: ["name", "phone", "city", "gstin", "address"],
  equipment: ["name", "type", "registration", "operator", "status", "fuel_per_hour"],
  materials: ["name", "sku", "unit", "stock", "reorder_level", "rate"]
};

for (const [route, fields] of Object.entries(resources)) {
  app.get(`/api/${route}`, auth, async (req, res) => {
    try {
      res.json(await q(
        `SELECT * FROM ${route} WHERE company_id=$1 ORDER BY id DESC`,
        [req.user.companyId]
      ));
    } catch {
      res.status(500).json({ error: "Database error" });
    }
  });

  app.post(`/api/${route}`, auth, async (req, res) => {
    try {
      const b = req.body || {};
      if (!b.name) return res.status(400).json({ error: "Name is required" });

      const columns = ["company_id", ...fields];
      const values = [req.user.companyId, ...fields.map(f => b[f] ?? null)];
      const marks = values.map((_, i) => `$${i + 1}`);

      const rows = await q(
        `INSERT INTO ${route} (${columns.join(",")})
         VALUES (${marks.join(",")}) RETURNING *`,
        values
      );
      res.status(201).json(rows[0]);
    } catch {
      res.status(400).json({ error: "Could not create record" });
    }
  });
}

app.get("/api/projects", auth, async (req, res) => {
  res.json(await q(
    `SELECT p.*, c.name AS customer_name
     FROM projects p LEFT JOIN customers c ON c.id=p.customer_id
     WHERE p.company_id=$1 ORDER BY p.id DESC`,
    [req.user.companyId]
  ));
});

app.post("/api/projects", auth, async (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.type) {
    return res.status(400).json({ error: "Name and type required" });
  }

  const code = (b.type === "Dredging" ? "DG" : "WB") +
    "-" + Date.now().toString().slice(-8);

  const rows = await q(
    `INSERT INTO projects(
       company_id,code,type,name,customer_id,location,start_date,end_date,
       target,unit,contract_value,status,progress,notes
     )
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
     RETURNING *`,
    [
      req.user.companyId, code, b.type, b.name, b.customer_id || null,
      b.location || null, b.start_date || null, b.end_date || null,
      Number(b.target) || 0, b.unit || "job", Number(b.contract_value) || 0,
      b.status || "In Progress", Number(b.progress) || 0, b.notes || null
    ]
  );

  res.status(201).json(rows[0]);
});

app.post("/api/progress", auth, async (req, res) => {
  const b = req.body || {};
  const p = (await q(
    "SELECT * FROM projects WHERE id=$1 AND company_id=$2",
    [b.project_id, req.user.companyId]
  ))[0];

  if (!p) return res.status(404).json({ error: "Project not found" });

  const rows = await q(
    `INSERT INTO progress_logs(project_id,work_date,quantity,unit,note)
     VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [p.id, b.work_date || new Date(), Number(b.quantity) || 0,
     b.unit || p.unit, b.note || null]
  );

  const total = (await q(
    "SELECT COALESCE(SUM(quantity),0) AS n FROM progress_logs WHERE project_id=$1",
    [p.id]
  ))[0].n;

  const progress = p.target
    ? Math.min(100, Number(total) / Number(p.target) * 100)
    : 0;

  await q("UPDATE projects SET progress=$1 WHERE id=$2", [progress, p.id]);

  res.status(201).json(rows[0]);
});

app.get("/api/invoices", auth, async (req, res) => {
  res.json(await q(
    "SELECT * FROM invoices WHERE company_id=$1 ORDER BY id DESC",
    [req.user.companyId]
  ));
});

app.post("/api/invoices", auth, async (req, res) => {
  const b = req.body || {};
  const number = b.number || "BP-INV-" + Date.now().toString().slice(-9);

  const rows = await q(
    `INSERT INTO invoices(
       company_id,project_id,number,client_name,invoice_date,
       subtotal,tax,total,status,due_date
     )
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     RETURNING *`,
    [
      req.user.companyId, b.project_id || null, number, b.client_name || "",
      b.invoice_date || new Date(), Number(b.subtotal) || 0,
      Number(b.tax) || 0, Number(b.total) || 0,
      b.status || "Unpaid", b.due_date || null
    ]
  );

  res.status(201).json(rows[0]);
});

app.get("/api/expenses", auth, async (req, res) => {
  res.json(await q(
    `SELECT e.*, p.name AS project_name
     FROM expenses e LEFT JOIN projects p ON p.id=e.project_id
     WHERE e.company_id=$1 ORDER BY e.id DESC`,
    [req.user.companyId]
  ));
});

app.post("/api/expenses", auth, async (req, res) => {
  const b = req.body || {};
  const rows = await q(
    `INSERT INTO expenses(
       company_id,project_id,expense_date,category,vendor,amount,notes
     )
     VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [
      req.user.companyId, b.project_id || null, b.expense_date || new Date(),
      b.category || "Other", b.vendor || null,
      Number(b.amount) || 0, b.notes || null
    ]
  );
  res.status(201).json(rows[0]);
});

app.get("/api/dashboard", auth, async (req, res) => {
  const c = req.user.companyId;
  const stats = (await q(
    `SELECT
       (SELECT count(*) FROM projects WHERE company_id=$1) AS projects,
       (SELECT COALESCE(sum(total),0) FROM invoices WHERE company_id=$1) AS revenue,
       (SELECT COALESCE(sum(amount),0) FROM expenses WHERE company_id=$1) AS expenses,
       (SELECT COALESCE(sum(total),0) FROM invoices
        WHERE company_id=$1 AND status!='Paid') AS outstanding`,
    [c]
  ))[0];

  const projects = await q(
    "SELECT * FROM projects WHERE company_id=$1 ORDER BY id DESC LIMIT 10",
    [c]
  );

  res.json({ stats, projects });
});

app.get("/api/reports", auth, async (req, res) => {
  const c = req.user.companyId;

  const totals = (await q(
    `SELECT
       (SELECT COALESCE(sum(total),0) FROM invoices WHERE company_id=$1) AS revenue,
       (SELECT COALESCE(sum(amount),0) FROM expenses WHERE company_id=$1) AS expenses,
       (SELECT COALESCE(sum(total),0) FROM invoices
        WHERE company_id=$1 AND status!='Paid') AS outstanding`,
    [c]
  ))[0];

  const projects = await q(
    `SELECT p.*,
       COALESCE((SELECT sum(total) FROM invoices i WHERE i.project_id=p.id),0) AS revenue,
       COALESCE((SELECT sum(amount) FROM expenses e WHERE e.project_id=p.id),0) AS costs
     FROM projects p WHERE p.company_id=$1`,
    [c]
  );

  res.json({
    ...totals,
    profit: Number(totals.revenue) - Number(totals.expenses),
    projects
  });
});

app.get("/api/backup", auth, async (req, res) => {
  const c = req.user.companyId;
  const out = {};

  for (const table of ["companies","customers","projects","equipment","materials","expenses","invoices"]) {
    out[table] = await q(
      `SELECT * FROM ${table} WHERE company_id=$1`,
      [c]
    );
  }

  res.json(out);
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../../frontend/index.html"));
});

app.listen(PORT, () => {
  console.log(`BillingPro 3.0 running at http://localhost:${PORT}`);
});
