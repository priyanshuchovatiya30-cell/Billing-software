const $ = s => document.querySelector(s);

const api = async (url, options = {}) => {
  const r = await fetch("/api" + url, {
    headers: {"Content-Type": "application/json"},
    ...options
  });
  if (!r.ok) {
    const data = await r.json().catch(() => ({}));
    throw Error(data.error || "Request failed");
  }
  return r.json();
};

const money = n => "₹" + Number(n || 0).toLocaleString("en-IN", {
  maximumFractionDigits: 2
});

async function login(e) {
  e.preventDefault();
  try {
    await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: $("#u").value,
        password: $("#p").value
      })
    });
    location.reload();
  } catch (e) {
    $("#err").textContent = e.message;
  }
}

async function boot() {
  try {
    const me = await api("/auth/me");
    $("#login").classList.add("hide");
    $("#app").classList.remove("hide");

    $("#app").innerHTML = `
      <div class="shell">
        <aside class="side">
          <h2>Billing<span>Pro</span></h2>
          <a href="#dashboard">📊 Dashboard</a>
          <a href="#projects">🚜 Projects</a>
          <a href="#customers">👥 Customers</a>
          <a href="#equipment">🚜 Equipment</a>
          <a href="#materials">📦 Materials</a>
          <a href="#billing">🧾 Billing</a>
          <a href="#expenses">💸 Expenses</a>
          <a href="#reports">📈 Reports</a>
          <a href="#backup">💾 Backup</a>
          <a href="#logout">🚪 Logout</a>
        </aside>
        <main class="main">
          <small class="muted">${me.company.name}</small>
          <h1 id="title">Dashboard</h1>
          <div id="view"></div>
        </main>
      </div>`;

    onhashchange = route;
    route();
  } catch {}
}

async function route() {
  const page = location.hash.slice(1) || "dashboard";
  $("#title").textContent = page[0].toUpperCase() + page.slice(1);

  if (page === "logout") {
    await api("/auth/logout", {method:"POST"});
    return location.reload();
  }

  const pages = {dashboard,projects,customers,equipment,materials,billing,expenses,reports,backup};
  (pages[page] || dashboard)();
}

async function dashboard() {
  const d = await api("/dashboard");

  $("#view").innerHTML = `
    <div class="grid">
      <div class="card"><span class="muted">Projects</span><b>${d.stats.projects}</b></div>
      <div class="card"><span class="muted">Revenue</span><b>${money(d.stats.revenue)}</b></div>
      <div class="card"><span class="muted">Expenses</span><b>${money(d.stats.expenses)}</b></div>
      <div class="card"><span class="muted">Outstanding</span><b>${money(d.stats.outstanding)}</b></div>
    </div>
    <section class="panel">
      <h2>Recent projects</h2>
      ${d.projects.map(x => `
        <div class="row">
          <span><b>${x.name}</b><br><small>${x.type} · ${x.location || ""}</small></span>
          <b>${Number(x.progress || 0).toFixed(0)}%</b>
        </div>`).join("") || "No projects yet."}
    </section>`;
}

async function projects() {
  const a = await api("/projects");
  $("#view").innerHTML = `
    <section class="panel">
      <button class="primary" onclick="addProject()">+ New project</button>
      <div class="table"><table>
        <tr><th>Code</th><th>Project</th><th>Type</th><th>Client</th><th>Progress</th><th>Contract</th></tr>
        ${a.map(x => `
          <tr>
            <td>${x.code}</td><td>${x.name}<br><small>${x.location || ""}</small></td>
            <td>${x.type}</td><td>${x.customer_name || "-"}</td>
            <td>${Number(x.progress || 0).toFixed(0)}%</td><td>${money(x.contract_value)}</td>
          </tr>`).join("")}
      </table></div>
    </section>`;
}

async function addProject() {
  const customers = await api("/customers");
  const name = prompt("Project name");
  if (!name) return;

  const type = prompt("Drilling or Dredging", "Drilling");
  const customerName = prompt("Customer name:
" + customers.map(x => x.name).join("
"));
  const customer = customers.find(x => x.name === customerName);

  await api("/projects", {
    method: "POST",
    body: JSON.stringify({
      name,
      type,
      customer_id: customer?.id,
      location: prompt("Location") || "",
      target: Number(prompt("Target quantity/depth") || 0),
      unit: prompt("Unit", "ft"),
      contract_value: Number(prompt("Contract value ₹") || 0)
    })
  });

  projects();
}

async function genericList(resource, columns, addFunction) {
  const rows = await api("/" + resource);

  $("#view").innerHTML = `
    <section class="panel">
      <button class="primary" onclick="${addFunction}()">+ Add</button>
      <div class="table"><table>
        <tr>${columns.map(c => `<th>${c[0]}</th>`).join("")}</tr>
        ${rows.map(x => `<tr>${columns.map(c => `<td>${c[1](x)}</td>`).join("")}</tr>`).join("")}
      </table></div>
    </section>`;
}

const val = x => x ?? "-";

async function customers() {
  genericList("customers", [
    ["Name", x => val(x.name)],
    ["Phone", x => val(x.phone)],
    ["City", x => val(x.city)],
    ["GSTIN", x => val(x.gstin)]
  ], "addCustomer");
}

async function addCustomer() {
  const name = prompt("Customer");
  if (!name) return;
  await api("/customers", {
    method:"POST",
    body:JSON.stringify({
      name, phone:prompt("Phone"), city:prompt("City"), gstin:prompt("GSTIN")
    })
  });
  customers();
}

async function equipment() {
  genericList("equipment", [
    ["Asset", x => val(x.name)],
    ["Type", x => val(x.type)],
    ["Registration", x => val(x.registration)],
    ["Operator", x => val(x.operator)],
    ["Status", x => val(x.status)]
  ], "addEquipment");
}

async function addEquipment() {
  const name = prompt("Equipment");
  if (!name) return;
  await api("/equipment", {
    method:"POST",
    body:JSON.stringify({
      name, type:prompt("Type"), registration:prompt("Registration"),
      operator:prompt("Operator"), status:"Available",
      fuel_per_hour:Number(prompt("Fuel/hour") || 0)
    })
  });
  equipment();
}

async function materials() {
  genericList("materials", [
    ["Material", x => val(x.name)],
    ["SKU", x => val(x.sku)],
    ["Unit", x => val(x.unit)],
    ["Stock", x => val(x.stock)],
    ["Reorder", x => val(x.reorder_level)],
    ["Rate", x => money(x.rate)]
  ], "addMaterial");
}

async function addMaterial() {
  const name = prompt("Material");
  if (!name) return;
  await api("/materials", {
    method:"POST",
    body:JSON.stringify({
      name, sku:prompt("SKU"), unit:prompt("Unit") || "pcs",
      stock:Number(prompt("Stock") || 0),
      reorder_level:Number(prompt("Reorder level") || 0),
      rate:Number(prompt("Rate ₹") || 0)
    })
  });
  materials();
}

async function billing() {
  genericList("invoices", [
    ["Number", x => x.number],
    ["Client", x => x.client_name],
    ["Date", x => String(x.invoice_date).slice(0,10)],
    ["Total", x => money(x.total)],
    ["Status", x => x.status]
  ], "addInvoice");
}

async function addInvoice() {
  const projectsData = await api("/projects");
  const code = prompt("Project code:
" + projectsData.map(x => x.code + " — " + x.name).join("
"));
  const project = projectsData.find(x => x.code === code);
  if (!project) return;

  const total = Number(prompt("Total ₹") || 0);
  if (!total) return;

  await api("/invoices", {
    method:"POST",
    body:JSON.stringify({
      project_id:project.id,
      client_name:project.customer_name || "",
      subtotal:total,
      tax:Number(prompt("Tax ₹") || 0),
      total
    })
  });

  billing();
}

async function expenses() {
  const a = await api("/expenses");
  $("#view").innerHTML = `
    <section class="panel">
      <button class="primary" onclick="addExpense()">+ Expense</button>
      <div class="table"><table>
        <tr><th>Date</th><th>Project</th><th>Category</th><th>Vendor</th><th>Amount</th></tr>
        ${a.map(x => `
          <tr>
            <td>${String(x.expense_date).slice(0,10)}</td>
            <td>${x.project_name || "-"}</td>
            <td>${x.category}</td>
            <td>${x.vendor || "-"}</td>
            <td>${money(x.amount)}</td>
          </tr>`).join("")}
      </table></div>
    </section>`;
}

async function addExpense() {
  const projectsData = await api("/projects");
  const code = prompt("Project code (optional)");
  const project = projectsData.find(x => x.code === code);
  const amount = Number(prompt("Amount ₹") || 0);
  if (!amount) return;

  await api("/expenses", {
    method:"POST",
    body:JSON.stringify({
      project_id:project?.id,
      category:prompt("Category") || "Other",
      vendor:prompt("Vendor"),
      amount
    })
  });

  expenses();
}

async function reports() {
  const d = await api("/reports");
  $("#view").innerHTML = `
    <div class="grid">
      <div class="card"><span class="muted">Revenue</span><b>${money(d.revenue)}</b></div>
      <div class="card"><span class="muted">Costs</span><b>${money(d.expenses)}</b></div>
      <div class="card"><span class="muted">Profit</span><b>${money(d.profit)}</b></div>
      <div class="card"><span class="muted">Outstanding</span><b>${money(d.outstanding)}</b></div>
    </div>
    <section class="panel">
      <h2>Project profitability</h2>
      ${d.projects.map(x => `
        <div class="row">
          <span>${x.name}</span>
          <b>${money(Number(x.revenue) - Number(x.costs))}</b>
        </div>`).join("")}
    </section>`;
}

async function backup() {
  const data = await api("/backup");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(
    [JSON.stringify(data, null, 2)],
    {type:"application/json"}
  ));
  a.download = "BillingPro-backup.json";
  a.click();

  $("#view").innerHTML =
    "<section class='panel'><h2>Backup</h2><p>JSON backup downloaded.</p></section>";
}

$("#loginForm").onsubmit = login;
boot();
