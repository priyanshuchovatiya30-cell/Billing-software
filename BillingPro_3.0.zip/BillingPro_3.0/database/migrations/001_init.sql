CREATE TABLE IF NOT EXISTS companies(
 id BIGSERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 gstin TEXT,
 phone TEXT,
 email TEXT,
 address TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 username TEXT NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'admin',
 active BOOLEAN NOT NULL DEFAULT true,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(company_id,username)
);

CREATE TABLE IF NOT EXISTS customers(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 phone TEXT,
 city TEXT,
 gstin TEXT,
 address TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS projects(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 code TEXT NOT NULL UNIQUE,
 type TEXT NOT NULL CHECK(type IN ('Drilling','Dredging')),
 name TEXT NOT NULL,
 customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
 location TEXT,
 start_date DATE,
 end_date DATE,
 target NUMERIC(14,2) DEFAULT 0,
 unit TEXT DEFAULT 'job',
 contract_value NUMERIC(14,2) DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'In Progress',
 progress NUMERIC(5,2) DEFAULT 0,
 notes TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS equipment(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 type TEXT,
 registration TEXT,
 operator TEXT,
 status TEXT DEFAULT 'Available',
 fuel_per_hour NUMERIC(12,2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS materials(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 sku TEXT,
 unit TEXT DEFAULT 'pcs',
 stock NUMERIC(14,2) DEFAULT 0,
 reorder_level NUMERIC(14,2) DEFAULT 0,
 rate NUMERIC(14,2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS progress_logs(
 id BIGSERIAL PRIMARY KEY,
 project_id BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 work_date DATE NOT NULL DEFAULT CURRENT_DATE,
 quantity NUMERIC(14,2) NOT NULL,
 unit TEXT,
 note TEXT
);

CREATE TABLE IF NOT EXISTS expenses(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 project_id BIGINT REFERENCES projects(id) ON DELETE SET NULL,
 expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
 category TEXT NOT NULL,
 vendor TEXT,
 amount NUMERIC(14,2) NOT NULL,
 notes TEXT
);

CREATE TABLE IF NOT EXISTS invoices(
 id BIGSERIAL PRIMARY KEY,
 company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
 project_id BIGINT REFERENCES projects(id) ON DELETE SET NULL,
 number TEXT NOT NULL UNIQUE,
 client_name TEXT NOT NULL,
 invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
 subtotal NUMERIC(14,2) NOT NULL,
 tax NUMERIC(14,2) NOT NULL DEFAULT 0,
 total NUMERIC(14,2) NOT NULL,
 status TEXT NOT NULL DEFAULT 'Unpaid',
 due_date DATE
);

CREATE TABLE IF NOT EXISTS audit_logs(
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 action TEXT NOT NULL,
 entity TEXT NOT NULL,
 entity_id BIGINT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_projects_company ON projects(company_id);
CREATE INDEX IF NOT EXISTS idx_customers_company ON customers(company_id);
CREATE INDEX IF NOT EXISTS idx_invoices_company ON invoices(company_id);
CREATE INDEX IF NOT EXISTS idx_expenses_company ON expenses(company_id);
