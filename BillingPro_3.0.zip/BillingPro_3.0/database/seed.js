require("dotenv").config();
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

(async () => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    let company = (await client.query("SELECT id FROM companies LIMIT 1")).rows[0];
    if (!company) {
      company = (await client.query(
        "INSERT INTO companies(name,phone,email) VALUES($1,$2,$3) RETURNING id",
        ["BillingPro Demo", "9876543210", "demo@example.com"]
      )).rows[0];
    }

    const hash = await bcrypt.hash("admin123", 12);
    await client.query(
      `INSERT INTO users(company_id,name,username,password_hash,role)
       VALUES($1,$2,$3,$4,$5)
       ON CONFLICT(company_id,username) DO NOTHING`,
      [company.id, "Administrator", "admin", hash, "admin"]
    );

    const customer = (await client.query(
      "INSERT INTO customers(company_id,name,phone,city) VALUES($1,$2,$3,$4) RETURNING id",
      [company.id, "Patel Construction", "9876543210", "Rajkot"]
    )).rows[0];

    await client.query(
      `INSERT INTO projects(company_id,code,type,name,customer_id,location,target,unit,contract_value)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT(code) DO NOTHING`,
      [company.id, "WB-DEMO01", "Drilling", "Demo Borewell",
       customer.id, "Rajkot", 500, "ft", 250000]
    );

    await client.query(
      `INSERT INTO equipment(company_id,name,type,registration,operator,status,fuel_per_hour)
       VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [company.id, "Rig Alpha", "Drilling Rig", "GJ-03-RG-01",
       "Team A", "Available", 8]
    );

    await client.query(
      `INSERT INTO equipment(company_id,name,type,registration,operator,status,fuel_per_hour)
       VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [company.id, "Dredger 01", "Dredger", "DRG-01",
       "Marine Team", "Available", 32]
    );

    await client.query("COMMIT");
    console.log("Seed complete: admin / admin123");
  } catch (e) {
    await client.query("ROLLBACK");
    console.error(e);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
})();
